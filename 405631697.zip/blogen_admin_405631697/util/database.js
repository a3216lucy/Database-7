const mysql = require('mysql2');

const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    database: '1071_405631697',
    password: '0000'
});

module.exports = pool.promise();